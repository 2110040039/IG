package Streams;
import java.time.LocalDate;import java.util.*;
import java.util.stream.Collectors;

 public class ProductService {
     private List<Product> products;

     public ProductService(List<Product> products) {
         this.products = products;
     }

     // 1. List Highest priced product
     public Product getHighestPricedProduct() {
         return products.stream()
                        .max(Comparator.comparing(Product::getPrice))
                        .orElse(null);
     }

     // 2. List lowest priced product
     public Product getLowestPricedProduct() {
         return products.stream()
                        .min(Comparator.comparing(Product::getPrice))
                        .orElse(null);
     }

     // 3. List products that have already expired
     public List<Product> getExpiredProducts() {
         LocalDate today = LocalDate.now();
         return products.stream()
                        .filter(product -> product.getExpiryDate().isBefore(today))
                        .collect(Collectors.toList());
     }

     // 4. List product names that will expire in the next 10 days
     public List<String> getProductsExpiringSoon() {
         LocalDate today = LocalDate.now();
         return products.stream()
                        .filter(product -> product.getExpiryDate().isBefore(today.plusDays(10)))
                        .map(Product::getName)
                        .collect(Collectors.toList());
     }

     // 5. Display count of products of different types
     public Map<String, Long> countProductsByType() {
         return products.stream()
                        .collect(Collectors.groupingBy(Product::getType, Collectors.counting()));
     }

     // 6. Display count of products based on Supplier name
     public Map<String, Long> countProductsBySupplier() {
         return products.stream()
                        .collect(Collectors.groupingBy(product -> product.getSupplier().getSname(), Collectors.counting()));
     }

     // Method to display all products
     public void displayProducts() {
         products.forEach(product -> System.out.println(product.getName() + " - " + product.getPrice()));
     }
 }
