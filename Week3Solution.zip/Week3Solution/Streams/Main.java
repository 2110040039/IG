package Streams;

import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Supplier supplier1 = new Supplier(1, "Supplier A");
        Supplier supplier2 = new Supplier(2, "Supplier B");
        Product product1 = new Product(1, "Milk", "Dairy", 10.0, 2.5, LocalDate.of(2023, 3, 1), supplier1);
        Product product2 = new Product(2, "Cheese", "Dairy", 5.0, 3.0, LocalDate.of(2023, 5, 1), supplier1);
        Product product3 = new Product(3, "Rice", "Pulses", 15.0, 1.2, LocalDate.of(2023, 4, 1), supplier2);
        Product product4 = new Product(4, "Chips", "Snacks", 20.0, 1.0, LocalDate.of(2025, 6, 15), supplier2);
        Product product5 = new Product(5, "Olive Oil", "Oils", 8.0, 5.0, LocalDate.of(2024, 8, 30), supplier1);
        ProductService productService = new ProductService(Arrays.asList(product1, product2, product3, product4, product5));
        Product highestPricedProduct = productService.getHighestPricedProduct();
        System.out.println("Highest Priced Product: " + highestPricedProduct.getName() + " - $" + highestPricedProduct.getPrice());

        // 2. List lowest priced product
        Product lowestPricedProduct = productService.getLowestPricedProduct();
        System.out.println("Lowest Priced Product: " + lowestPricedProduct.getName() + " - $" + lowestPricedProduct.getPrice());

        // 3. List products that already expired
        System.out.println("Expired Products:");
        productService.getExpiredProducts().forEach(product -> System.out.println(product.getName()));

        // 4. List product names that will expire in the next 10 days
        System.out.println("Products Expiring in the Next 10 Days:");
        productService.getProductsExpiringSoon().forEach(System.out::println);

        // 5. Display count of products of different types
        System.out.println("Count of Products by Type:");
        productService.countProductsByType().forEach((type, count) -> System.out.println(type + ": " + count));

        // 6. Display count of products based on Supplier name
        System.out.println("Count of Products by Supplier:");
        productService.countProductsBySupplier().forEach((supplierName, count) -> System.out.println(supplierName + ": " + count));
    }
}

